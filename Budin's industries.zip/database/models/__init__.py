from sqlalchemy import Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base

class Base(declarative_base):
    pass
    